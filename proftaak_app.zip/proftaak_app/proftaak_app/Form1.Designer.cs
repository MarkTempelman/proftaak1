﻿namespace proftaak_app
{
    partial class Meervoud
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LMeervoud2 = new System.Windows.Forms.Label();
            this.LOutput = new System.Windows.Forms.Label();
            this.TBInput = new System.Windows.Forms.TextBox();
            this.LMeervoud = new System.Windows.Forms.Label();
            this.BTCheck = new System.Windows.Forms.Button();
            this.BTSkip = new System.Windows.Forms.Button();
            this.LGoed = new System.Windows.Forms.Label();
            this.LFout = new System.Windows.Forms.Label();
            this.LNumFout = new System.Windows.Forms.Label();
            this.LNumGoed = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LMeervoud2
            // 
            this.LMeervoud2.AutoSize = true;
            this.LMeervoud2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LMeervoud2.Location = new System.Drawing.Point(6, 89);
            this.LMeervoud2.Name = "LMeervoud2";
            this.LMeervoud2.Size = new System.Drawing.Size(339, 37);
            this.LMeervoud2.TabIndex = 0;
            this.LMeervoud2.Text = "Geef de meervoud van";
            // 
            // LOutput
            // 
            this.LOutput.AutoSize = true;
            this.LOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LOutput.Location = new System.Drawing.Point(351, 89);
            this.LOutput.Name = "LOutput";
            this.LOutput.Size = new System.Drawing.Size(0, 37);
            this.LOutput.TabIndex = 1;
            // 
            // TBInput
            // 
            this.TBInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TBInput.Location = new System.Drawing.Point(110, 154);
            this.TBInput.Name = "TBInput";
            this.TBInput.Size = new System.Drawing.Size(241, 62);
            this.TBInput.TabIndex = 2;
            // 
            // LMeervoud
            // 
            this.LMeervoud.AutoSize = true;
            this.LMeervoud.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LMeervoud.Location = new System.Drawing.Point(112, 9);
            this.LMeervoud.Name = "LMeervoud";
            this.LMeervoud.Size = new System.Drawing.Size(239, 55);
            this.LMeervoud.TabIndex = 3;
            this.LMeervoud.Text = "Meervoud";
            // 
            // BTCheck
            // 
            this.BTCheck.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTCheck.Location = new System.Drawing.Point(263, 247);
            this.BTCheck.Name = "BTCheck";
            this.BTCheck.Size = new System.Drawing.Size(182, 51);
            this.BTCheck.TabIndex = 4;
            this.BTCheck.Text = "Controleer";
            this.BTCheck.UseVisualStyleBackColor = true;
            this.BTCheck.Click += new System.EventHandler(this.BTCheck_Click);
            // 
            // BTSkip
            // 
            this.BTSkip.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTSkip.Location = new System.Drawing.Point(12, 247);
            this.BTSkip.Name = "BTSkip";
            this.BTSkip.Size = new System.Drawing.Size(182, 51);
            this.BTSkip.TabIndex = 6;
            this.BTSkip.Text = "Sla over";
            this.BTSkip.UseVisualStyleBackColor = true;
            // 
            // LGoed
            // 
            this.LGoed.AutoSize = true;
            this.LGoed.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LGoed.Location = new System.Drawing.Point(103, 24);
            this.LGoed.Name = "LGoed";
            this.LGoed.Size = new System.Drawing.Size(95, 37);
            this.LGoed.TabIndex = 7;
            this.LGoed.Text = "Goed";
            // 
            // LFout
            // 
            this.LFout.AutoSize = true;
            this.LFout.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LFout.Location = new System.Drawing.Point(103, 64);
            this.LFout.Name = "LFout";
            this.LFout.Size = new System.Drawing.Size(82, 37);
            this.LFout.TabIndex = 8;
            this.LFout.Text = "Fout";
            // 
            // LNumFout
            // 
            this.LNumFout.AutoSize = true;
            this.LNumFout.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNumFout.Location = new System.Drawing.Point(204, 64);
            this.LNumFout.Name = "LNumFout";
            this.LNumFout.Size = new System.Drawing.Size(35, 37);
            this.LNumFout.TabIndex = 10;
            this.LNumFout.Text = "0";
            // 
            // LNumGoed
            // 
            this.LNumGoed.AutoSize = true;
            this.LNumGoed.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LNumGoed.Location = new System.Drawing.Point(204, 24);
            this.LNumGoed.Name = "LNumGoed";
            this.LNumGoed.Size = new System.Drawing.Size(35, 37);
            this.LNumGoed.TabIndex = 9;
            this.LNumGoed.Text = "0";
            // 
            // Meervoud
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 376);
            this.Controls.Add(this.LNumFout);
            this.Controls.Add(this.LNumGoed);
            this.Controls.Add(this.LFout);
            this.Controls.Add(this.LGoed);
            this.Controls.Add(this.BTSkip);
            this.Controls.Add(this.BTCheck);
            this.Controls.Add(this.LMeervoud);
            this.Controls.Add(this.TBInput);
            this.Controls.Add(this.LOutput);
            this.Controls.Add(this.LMeervoud2);
            this.Name = "Meervoud";
            this.Text = "Buddy bot";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LMeervoud2;
        private System.Windows.Forms.Label LOutput;
        private System.Windows.Forms.TextBox TBInput;
        private System.Windows.Forms.Label LMeervoud;
        private System.Windows.Forms.Button BTCheck;
        private System.Windows.Forms.Button BTSkip;
        private System.Windows.Forms.Label LGoed;
        private System.Windows.Forms.Label LFout;
        private System.Windows.Forms.Label LNumFout;
        private System.Windows.Forms.Label LNumGoed;
    }
}

